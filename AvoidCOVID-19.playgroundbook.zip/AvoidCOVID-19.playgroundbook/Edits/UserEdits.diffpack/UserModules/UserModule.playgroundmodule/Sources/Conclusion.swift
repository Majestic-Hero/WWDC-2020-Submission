


import SpriteKit

public class Conclusion: SKScene{
    
    public override func didMove(to view: SKView) {
        
        let bg = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "blue-background-clipart-1392210818CaU.jpg")))
        bg.zPosition = -10
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        
        let introLbl = SKLabelNode(text: "Thanks for Reviewing!")
        let expLbl = SKLabelNode(text: "Hopefully everyone is staying safe and healthy!")
        
        introLbl.fontSize = 30.0
        expLbl.fontSize = 25.0
        
        introLbl.position = CGPoint(x: frame.midX, y: (frame.midY + 100))
        expLbl.position  = CGPoint(x: frame.midX, y: (frame.midY - 60))
        
        introLbl.zPosition = 3
        expLbl.zPosition = 3
        
        introLbl.fontName = "AvenirNext-Bold"
        expLbl.fontName = "AvenirNext-Bold"
        
        introLbl.fontColor = .black
        expLbl.fontColor = .darkGray
        
        addChild(introLbl)
        addChild(expLbl)
        addChild(bg)
    }
}
