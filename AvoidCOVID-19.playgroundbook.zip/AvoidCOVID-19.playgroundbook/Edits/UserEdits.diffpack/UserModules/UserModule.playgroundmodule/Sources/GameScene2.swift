import SpriteKit

public class GameScene2: SKScene, SKPhysicsContactDelegate {
    
    
    var player: SKSpriteNode!
    
    // List of Items to Collect: 
    var mask: SKSpriteNode!
    var gloves: SKSpriteNode!
    var tissue: SKSpriteNode!
    var gameOver = false
    var sanitizer: SKSpriteNode!
    var score: Int = 0
    var scoreLbl = SKLabelNode(text: "Score: ")
    var infoLbl = SKLabelNode(text: "There are 4 items hidden around the map: Mask, Gloves, Hand Sanitizer, and Tissue. Try and find them!")
    
    
    // Other variables
    var socialDistancingLength: CGFloat = 1.5
    var movingPlayer = false
    var offset: CGPoint!
    
    public override func didMove(to view: SKView) {
        
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        physicsBody?.friction = 0.0
        physicsWorld.contactDelegate = self
        
        scoreLbl.text = "Score: \(score)"
        scoreLbl.fontName = "AvenirNext-Bold"
        infoLbl.fontName = "AvenirNext-Bold"
        scoreLbl.fontColor = .white
        infoLbl.fontColor = .white
        scoreLbl.fontSize = 20.0
        infoLbl.fontSize = 13.0
        scoreLbl.position = CGPoint(x: frame.midX, y: frame.maxY - 40.0)
        infoLbl.position = CGPoint(x: frame.midX, y: frame.maxY - 65.0)
        scoreLbl.zPosition = 10
        infoLbl.zPosition = 10
        
        
        let bg = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "Bg2.png")))
        bg.zPosition = -10
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        
        player = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "Player.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        player.position = CGPoint(x: frame.midX - 200.0, y: frame.midY)
        player.addCircle(radius: 30.0, edgeColor: .green, filled: true)
        player.setScale(1)
        player.physicsBody = SKPhysicsBody(circleOfRadius: 30.0)
        player.physicsBody?.isDynamic = false
        player.zPosition = 9
        player.physicsBody?.categoryBitMask = Bitmasks.player
        player.physicsBody?.contactTestBitMask = Bitmasks.enemy
        
        
        // Individual Items
        
        mask = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "mask.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        gloves = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "gloves.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        tissue = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "tissue.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        sanitizer = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "sanitizer.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        
        mask.position = CGPoint(x: frame.midX + 250.0, y: frame.midY + 210.0)
        gloves.position = CGPoint(x: frame.midX + 450.0, y: frame.midY + 135.0)
        tissue.position = CGPoint(x: frame.midX + 95.0, y: frame.midY - 185.0)
        sanitizer.position = CGPoint(x: frame.midX + 210.0, y: frame.midY - 7.8)
        
        
        // Individual Items' Physics
        
        createPersonPhysics(person: mask)
        createPersonPhysics(person: gloves)
        createPersonPhysics(person: tissue)
        createPersonPhysics(person: sanitizer)
        
        // Add circle functions
        
        mask.addCircle(radius: 36.0, edgeColor: .lightGray, filled: true);
        gloves.addCircle(radius: 36.0, edgeColor: .lightGray, filled: true);
        tissue.addCircle(radius: 36.0, edgeColor: .brown, filled: true);
        sanitizer.addCircle(radius: 35.0, edgeColor: .yellow, filled: true);
        
        addChild(scoreLbl)
        addChild(infoLbl)
        addChild(mask)
        addChild(gloves)
        addChild(tissue)
        addChild(sanitizer)
        addChild(player)
        addChild(bg)
    }
    
    func createPersonPhysics(person: SKSpriteNode){
        person.physicsBody = SKPhysicsBody(circleOfRadius: 36.0)
        person.physicsBody?.affectedByGravity = false
        person.setScale(0.3)
        person.zPosition = 9
        person.physicsBody?.categoryBitMask = Bitmasks.enemy
        person.physicsBody?.contactTestBitMask = Bitmasks.player
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !gameOver else {return}
        guard let touch = touches.first else {return}
        let touchLocation = touch.location(in: self)
        let touchPlace = nodes(at: touchLocation)
        
        for node in touchPlace {
            if node == player{
                movingPlayer = true
                offset = CGPoint(x: touchLocation.x - player.position.x, y: touchLocation.y - player.position.y)
            }
        }
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !gameOver else {return}
        guard let touch = touches.first else {return}
        let touchLocation = touch.location(in: self)
        let newPlayerPos = CGPoint(x: touchLocation.x - offset.x, y: touchLocation.y - offset.y)
        
        player.run(SKAction.move(to: newPlayerPos, duration: 0.01))
        
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        movingPlayer = false
    }
    
    
    public func didBegin(_ contact: SKPhysicsContact) {
        if contact.bodyA.categoryBitMask == Bitmasks.enemy || contact.bodyB.categoryBitMask == Bitmasks.enemy {
            score += 1
            scoreLbl.text = "Score: \(score)"
        } 
        
        if score >= 4 {
            scoreLbl.text = "YOU ARE PREPARED TO DEFEAT COVID-19! Click the right arrow above to continue!"
            mask.zPosition = -11
            gloves.zPosition = -11
            tissue.zPosition = -11
            sanitizer.zPosition = -11
            scoreLbl.position = CGPoint(x: frame.midX, y: frame.midY + 50.0)
            scoreLbl.fontSize = 20.0
            infoLbl.zPosition = -11
            gameOver = true
        }
        
    }
}

