import SpriteKit
import UIKit

public class GameScene3: SKScene, SKPhysicsContactDelegate {
    
    // Variables
    var player: SKSpriteNode!
    var bathtub: SKSpriteNode!
    var curtain: SKSpriteNode!
    var gloves: SKSpriteNode!
    var mask: SKSpriteNode!
    var click1: SKSpriteNode!
    var click2: SKSpriteNode!
    var click3: SKSpriteNode!
    var click4: SKSpriteNode!
    var gameOver = false
    var infoLbl = SKLabelNode(text: "Now that you have arrived home, clean yourself up!")
    
    public override func didMove(to view: SKView) {
        
        // Setting background
        let bg = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "bathroom.png")))
        bg.zPosition = -10
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        
        // Setting up bathtub
        bathtub = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "bathtub.png")))
        bathtub.zPosition = -4
        bathtub.position = CGPoint(x: frame.midX, y: frame.midY)
        
        // Setting up curtain
        curtain = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "curtain.png")))
        curtain.zPosition = -11
        curtain.position = CGPoint(x: frame.midX, y: frame.midY)
        
        // Setting up gloves
        gloves = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "gloves.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        gloves.position = CGPoint(x: frame.midX + 50.0, y: frame.midY - 130.0)
        gloves.zPosition = -11
        
        // Setting up mask
        mask = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "mask.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        mask.position = CGPoint(x: frame.midX, y: frame.midY - 20.0)
        mask.zPosition = -11
        
        // Setting up label
        infoLbl.fontName = "AvenirNext-Bold"
        infoLbl.fontColor = .black
        infoLbl.fontSize = 20.0
        infoLbl.position = CGPoint(x: frame.midX, y: frame.maxY - 40.0)
        infoLbl.zPosition = 10
        
        // Setting up player
        player = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "ready.png")), color: .clear, size: CGSize(width: size.width * 0.35, height: size.height))
        player.setScale(0.5)
        player.position = CGPoint(x: frame.maxX, y: frame.minY)
        let moveToFrame = SKAction.move(to: CGPoint(x: frame.midX, y: frame.midY - 100.0), duration: 2.0)
        player.run(moveToFrame)
        player.zPosition = -5
        
        // First click
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.1) {
            self.infoLbl.text = "Click on the trash to throw away your mask and gloves!"
            self.click1.zPosition = 11
        }
        
        // Setting up clicks
            // Click 1
        click1 = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "click.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        click1.zPosition = -11
        click1.setScale(0.25)
        click1.addCircle(radius: 80, edgeColor: .green, filled: true)
        click1.position = CGPoint(x: frame.maxX - 60.0, y: frame.minY + 50.0)
        
            // Click 2
        click2 = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "click.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        click2.zPosition = -11
        click2.setScale(0.25)
        click2.addCircle(radius: 80, edgeColor: .green, filled: true)
        click2.position = CGPoint(x: frame.midX + 60.0, y: frame.midY + 70.0)
        
            // Click 3
        click3 = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "click.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        click3.zPosition = -11
        click3.addCircle(radius: 70, edgeColor: .green, filled: true)
        click3.setScale(0.25)
        click3.position = CGPoint(x: frame.midX + 350.0, y: frame.midY + 45.0)
        
            // Click 4
        click4 = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "click.png")), color: .clear, size: CGSize(width: size.width * 0.05, height: size.width * 0.05))
        click4.zPosition = -11
        click4.addCircle(radius: 70, edgeColor: .green, filled: true)
        click4.setScale(0.25)
        click4.position = CGPoint(x: 150.0, y: frame.midY - 100.0)
        
        // Adding Sprites
        addChild(click1)
        addChild(click2)
        addChild(click3)
        addChild(click4)
        addChild(mask)
        addChild(gloves)
        addChild(bathtub)
        addChild(curtain)
        addChild(infoLbl)
        addChild(player)
        addChild(bg)
        
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !gameOver else {return}
        guard let touch = touches.first else {return}
        let touchLocation = touch.location(in: self)
        let touchPlace = nodes(at: touchLocation)
        
        for node in touchPlace {
            if node == click1{
                throwAwayGlovesandMask(player: player, gloves: gloves, mask: mask, click: click1, click2: click2)
            } else if node == click2{
                washHands(player: player, click: click2, click2: click3)
            } else if node == click3{
                cleanPhone(player: player, click: click3, click2: click4)
            } else if node == click4{
                shower(player: player, click: click4, curtain: curtain)
            }
        }
    }
    
    func throwAwayGlovesandMask(player: SKSpriteNode, gloves: SKSpriteNode, mask: SKSpriteNode, click: SKSpriteNode, click2: SKSpriteNode){
        player.texture = SKTexture(image: #imageLiteral(resourceName: "ready_glovesOFF.png"))
        let toTrash = SKAction.move(to: CGPoint(x: frame.maxX - 60.0, y: frame.minY + 90.0), duration: 1.0)
        
        gloves.zPosition = 11
        mask.zPosition = 11
        gloves.run(toTrash)
        mask.run(toTrash)
        click.zPosition = -11
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
            self.mask.zPosition = -11
            self.gloves.zPosition = -11
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.infoLbl.text = "Click on the sink to wash your hands!"
                click2.zPosition = 11
            }
        }
        
    }
    
    
    func washHands(player: SKSpriteNode, click: SKSpriteNode, click2: SKSpriteNode){
        player.texture = SKTexture(image: #imageLiteral(resourceName: "washhands.png"))
        let toSink = SKAction.move(to: CGPoint(x: frame.midX + 10.0, y: frame.midY + 40.0), duration: 1.0)
        let goBack = SKAction.move(to: CGPoint(x: frame.midX, y: frame.midY - 100.0), duration: 2.0)
        
        player.run(toSink)
        click.zPosition = -11
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
            player.texture = SKTexture(image: #imageLiteral(resourceName: "washands2.png"))
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                player.texture = SKTexture(image: #imageLiteral(resourceName: "ready_glovesOFF.png"))
                player.run(goBack)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    self.infoLbl.text = "Click on the table to clean your iPhone!"
                    click2.zPosition = 11
                }
            }
        }
    }
    
    func cleanPhone(player: SKSpriteNode, click: SKSpriteNode, click2: SKSpriteNode){
        player.texture = SKTexture(image: #imageLiteral(resourceName: "washhands.png"))
        let toTable = SKAction.move(to: CGPoint(x: frame.midX + 250.0, y: frame.midY), duration: 2.0)
        let goBack = SKAction.move(to: CGPoint(x: frame.midX, y: frame.midY - 100.0), duration: 2.0)
        
        player.run(toTable)
        click.zPosition = -11
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            player.texture = SKTexture(image: #imageLiteral(resourceName: "cleanPhone.png"))
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                player.texture = SKTexture(image: #imageLiteral(resourceName: "ready_glovesOFF.png"))
                player.run(goBack)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    self.infoLbl.text = "Click on the bathtub to shower!"
                    click2.zPosition = 12
                }
            }
        }
    }
    
    func shower(player: SKSpriteNode, click: SKSpriteNode, curtain: SKSpriteNode){
        player.texture = SKTexture(image: #imageLiteral(resourceName: "showerGoing.png"))
        let toShower = SKAction.move(to: CGPoint(x: 150.0, y: frame.midY + 30.0), duration: 1.5)
        let goBack = SKAction.move(to: CGPoint(x: frame.midX, y: frame.midY - 100.0), duration: 2.0) 
        
        player.run(toShower)
        click.zPosition = -11
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
            curtain.zPosition = 11
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                curtain.zPosition = -11
                player.texture = SKTexture(image: #imageLiteral(resourceName: "ready_glovesOFF.png"))
                player.run(goBack)
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.1) {
                    self.infoLbl.text = "You stopped the virus from spreading in your house! Click the right arrow above to continue!"
                }
            }
        }
    }
}
