
public struct Bitmasks{
    static let player: UInt32 = 1 << 1
    static let enemy: UInt32 = 1 << 2
    static let uninfectedPerson: UInt32 = 1 << 3
    static let mask: UInt32 = 1 << 4
    static let gloves: UInt32 = 1 << 5
    static let tissue: UInt32 = 1 << 6
    static let sanitizer: UInt32 = 1 << 7
}
