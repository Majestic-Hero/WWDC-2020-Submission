

import SpriteKit


public class Introduction: SKScene{

    
    public override func didMove(to view: SKView) {
        
        let bg = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "blue-background-clipart-1392210818CaU.jpg")))
        bg.zPosition = -10
        bg.position = CGPoint(x: frame.midX, y: frame.midY)
        
        let introLbl = SKLabelNode(text: "Welcome To Avoid COVID-19!")
        let expLbl = SKLabelNode(text: "A Series of Games to Educate Lessons About COVID-19")
        let nameLbl = SKLabelNode(text: "Click the right arrow above to continue!")
        
        introLbl.fontSize = 30.0
        nameLbl.fontSize = 15.0
        expLbl.fontSize = 25.0
        
        introLbl.position = CGPoint(x: frame.midX, y: (frame.midY + 100))
        nameLbl.position  = CGPoint(x: frame.midX, y: (frame.midY - 100))
        expLbl.position  = CGPoint(x: frame.midX, y: (frame.midY - 60))
        
        introLbl.zPosition = 3
        nameLbl.zPosition = 3
        expLbl.zPosition = 3
        
        introLbl.fontName = "AvenirNext-Bold"
        nameLbl.fontName = "AvenirNext-Bold"
        expLbl.fontName = "AvenirNext-Bold"
        
        introLbl.fontColor = .black
        nameLbl.fontColor = .gray
        expLbl.fontColor = .darkGray
        
        addChild(nameLbl)
        addChild(introLbl)
        addChild(expLbl)
        addChild(bg)
    }
}
